/**
 * General purpose sample beans that can be used with tests.
 */
package org.springframework.tests.sample.beans;
